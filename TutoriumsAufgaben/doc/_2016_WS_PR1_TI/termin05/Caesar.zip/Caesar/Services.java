
/**
 * Eine Sammlung mehrerer nicht zusammengehöriger Methoden.
 * (Achtung, nicht objektorientiert!)
 */
public class Services {
    
    /**
    * Gibt an, ob die Zeichenkette einen Vokal enthaelt. Auswertungen:
    * 
    * enthaeltVokal("brei") -> enthaeltVokal("rei") -> enthaeltVokal("ei") -> true
    * enthaeltVokal("xyz") -> enthaeltVokal("yz") -> enthaeltVokal("z") -> enthaeltVokal("") -> false
    */
    public boolean enthaeltVokal(String s)
    {
        // Todo: umstrukturieren, so dass die Methode nur ein Return-Statement hat
        if (s.length() == 0)
        {
            return false;
        }
        return istVokal(s.charAt(0)) || enthaeltVokal (s.substring(1));
    }
    
    /**
     * Diese Methode kodiert das gegebene Wort nach dem Prinzip der
     * Caesar-Verschluesselung. Jeder Buchstabe wird durch den im Alphabet nachfolgenden
     * Buchstaben ersetzt. Der letzte Buchstabe im Alphabet, das z, wird durch ein 
     * a ersetzt. Es werden nur Kleinbuchstaben ersetzt, alle anderen Zeichen bleiben, 
     * wie sie waren.
     * @param wort ein beliebiger String, darf nicht null sein
     * @return die Kodierung des gegebenen Worts nach der Caesar-Verschluesselung 
     */
    public String caesarVerschluesseln(String wort)
    {
        // Todo: implementieren!
        return null;
    }
 
    /**
     * Gibt an, ob das gegebene Zeichen ein Vokal ist.
     */
    private boolean istVokal(char c)
    {
        c = Character.toLowerCase(c);
        return c=='a'||c=='e'||c=='i'||c=='o'||c=='u';
    }
}
