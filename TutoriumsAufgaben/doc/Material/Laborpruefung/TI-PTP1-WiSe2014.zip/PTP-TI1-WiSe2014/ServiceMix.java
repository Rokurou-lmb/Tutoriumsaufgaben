
/**
 * Ein Interface mit mehreren Dienstleister-Operationen.
 * 
 * @author Petra Becker-Pechau, Axel Schmolitzky
 * @version WiSe 2014/2015
 */
interface ServiceMix
{
    /**
     * Diese Methode kodiert das gegebene Wort nach dem Prinzip der
     * Caesar-Verschluesselung. Jeder Buchstabe wird durch den im Alphabet nachfolgenden
     * Buchstaben ersetzt. Der letzte Buchstabe im Alphabet, das z, wird durch ein 
     * a ersetzt. Es werden nur Kleinbuchstaben ersetzt, alle anderen Zeichen bleiben, 
     * wie sie waren.
     * @param wort ein beliebiger String, darf nicht null sein
     * @return die Kodierung des gegebenen Worts nach der Caesar-Verschluesselung 
     */
    public String caesarVerschluesseln(String wort);
    
    /**
     * Verbindet die in einem String-Array gegebenen Worte zu einem einzigen String.
     * Der String enthaelt als Trennzeichen zwischen den Worten ein Semikolon. Am 
     * Anfang oder am Schluss soll kein Semikolon stehen.
     * Beispiel: fuer ein Array der Laenge 2 mit den Worten "Hallo" und "Welt" liefert
     * diese Methode als Ergebnis den String "Hallo;Welt".
     * @param worte ein Array von nicht-leeren Strings, darf nicht null sein
     * @return einen String, der die im Array gegebenen Worte verbindet, Trennzeichen: Semikolon.
     */
    public String worteVerbinden(String[] worte);
    
    /**
     * Liefert das uebergebene Wort ohne Vokale. Fuer den Parameter "HAllo"      
     * liefert diese Methode beispielweise den String "Hll".
     * @param ein beliebiges deutsches Wort; darf nicht null sein und muss nur aus Buchstaben
     * (ohne Umlaute) bestehen 
     * @return einen String mit den Konsonanten des gegebenen Strings in der urspruenglichen Reihenfolge.
     */
    public String ohneVokale(String wort);
    
    
    /**
     * Diese Methode liefert ein Array der gleichen Laenge wie der aktuelle Parameter, 
     * dieses Ergebnis-Array enthaelt ausschliesslich negative Zahlen.
     * Negative Zahlen im Eingabe-Array werden unveraendert in das Ergebnis-Array uebernommen,
     * positive Zahlen werden negiert. 
     * Für den Parameter {1, -3, 2} beispielsweise liefert diese Methode {-1, -3, -2}.
     * @param zahlen ein Array von int-Werten, darf nicht null sein
     * @return negative Werte der uebergebenen Zahlen, darf nicht null sein.
     */
    public int[] negativeZahlen(int[] zahlen);
    

    /**
    * Gibt an, ob die Zeichenkette eine Ziffer enthaelt.
    * @param eine beliebige Zeichenkette, darf nicht null sein.
    * @return ob die Zeichenkette eine Ziffer enthaelt.
    */
   public boolean enthaeltZiffer(String s);
    
}