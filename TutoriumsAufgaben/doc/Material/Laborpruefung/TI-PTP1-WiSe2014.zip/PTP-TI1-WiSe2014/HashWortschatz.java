import java.util.List;
import java.util.LinkedList;

/**
 * Ein Wortschatz ist eine Menge von Woertern.
 * Es koennen Woerter hinzugefuegt und entfernt werden, es kann abgefragt werden,
 * ob ein bestimmtes Wort im Wortschatz enthalten ist, und es kann die Anzahl
 * der gespeicherten Woerter abgefragt werden.
 * 
 * @author Musterloeseung aus SE1, ueberarbeitet von Petra Becker-Pechau
 * @version WiSe 2014 / 2015
 */
class HashWortschatz implements Wortschatz
{
    private HashWertBerechner _berechner;
    private WortListe[] _hashTabelle;
    private int _anzahlWoerter;
    
    /**
     * Erzeugt ein beispielhaftes Exemplar von HashWortschatz mit 10 
     * Woertern.
     * 
     * @param groesse die initiale Groesse der Hashtabelle, muss > 0 sein.
     */
    public static HashWortschatz erzeugeBeispielWortschatz(int groesse)
    {
        HashWertBerechner berechner = new Delegation();
        HashWortschatz wortschatz = new HashWortschatz(berechner, groesse);
       
        String [] text = {"Dies", "ist", "ein", "Beispieltext", "zum", "Ausprobieren", 
            "und", "Visualisieren", "des", "HashWortschatzes"};  
                
        for (String wort : text)
        {
            wortschatz.fuegeWortHinzu(wort);
        }

        return wortschatz;

    }
    
    /**
     * Initialisiert ein neues Exemplar von HashWortschatz.
     * 
     * @param berechner der Berechner, welcher die Hashfunktion umsetzt
     * @param groesse die (initiale) Groesse der Hashtabelle
     */
    public HashWortschatz(HashWertBerechner berechner, int groesse)
    {
        _berechner = berechner;
        initialisiereHashWortschatz(groesse);
    }
    
    /**
     * Diese Methode initialisiert den Hashwortschatz. Sie erzeugt eine neue 
     * HashTabelle mit leeren Wortlisten. Die Hashtabelle erhaelt die gegebene 
     * Groesse. Nach Ausfuehrung dieser Methode ist der HashWortschatz leer, 
     * die Anzahl der Woerter ist 0.
     * 
     * @param groesse die Groesse der Hashtabelle
     */
    private void initialisiereHashWortschatz(int groesse)
    {
        _hashTabelle = new WortListe[groesse];
        for (int i = 0; i < groesse; ++i)
        {
            _hashTabelle[i] = new WortListe();
        }
        _anzahlWoerter = 0;
    }
    
    /**
     * Liefert zu einem Wort diejenige Wortliste,
     * in die es eingefuegt werden muss bzw. in der es enthalten sein muesste.
     */
    private WortListe wortListeFuer(String wort)
    {
        int hash = _berechner.hashWert(wort);
        int index = hash % _hashTabelle.length;
        index = Math.abs(index);
        WortListe liste = _hashTabelle[index];
        return liste;
    }

    /**
     * Fuege ein Wort zum Wortschatz hinzu, sofern es noch nicht enthalten ist.
     * 
     * @param wort das hinzuzufuegende Wort
     */
    public void fuegeWortHinzu(String wort)
    {
        
        WortListe liste = wortListeFuer(wort);
        if (!wortListeFuer(wort).enthaeltWort(wort))
        {
            // ToDo: wenn die Anzahl der bereits enthaltenen Woerter der  
            // Laenge der Hashtabelle entspricht, dann soll die Tabellenlaenge
            // verdoppelt werden und ein Rehashing durchgefuehrt werden.
        
            wortListeFuer(wort).fuegeWortHinzu(wort);
            ++_anzahlWoerter;
        }
    }
        
    /**
     * Entferne ein Wort aus dem Wortschatz, sofern es darin enthalten ist.
     * 
     * @param wort das zu entfernende Wort
     */
    public void entferneWort(String wort)
    {
        WortListe liste = wortListeFuer(wort);
        if (liste.enthaeltWort(wort))
        {
            liste.entferneWort(wort);
            --_anzahlWoerter;
        }
    }
    
    /**
     * Gib an, ob ein Wort im Wortschatz enthalten ist.
     * 
     * @param wort das zu ueberpruefende Wort
     * @return true, falls das Wort enthalten ist, false sonst
     */
    public boolean enthaeltWort(String wort)
    {
        WortListe liste = wortListeFuer(wort);
        return liste.enthaeltWort(wort);
    }
    
    /**
     * Gib an, wieviele Woerter im Wortschatz enthalten sind.
     * 
     * @return die Anzahl der Woerter im Wortschatz
     */
    public int anzahlWoerter()
    {
        return _anzahlWoerter;
    }

    /**
     * Schreibt den Wortschatz auf die Konsole (als Debugging-Hilfe gedacht).
     */
    public void schreibeAufKonsole()
    {
        String[] strings = wortListenStrings();
        for (int i = 0; i < strings.length; i++)
        {
            System.out.println("[" + i + "]: "  + strings[i]);
        }
    }
    
    /**
     * Liefert ein Array von beschreibenden Strings. Der String an Index n beschreibt 
     * jeweils den Inhalt der n-ten Wortliste 
     */
    public String[] wortListenStrings()
    {
        String[] ergebnis = new String[_hashTabelle.length];
        for (int i = 0; i < _hashTabelle.length; ++i)
        {
            ergebnis[i] = _hashTabelle[i].toString();
        }
        return ergebnis;
    }
    
}



