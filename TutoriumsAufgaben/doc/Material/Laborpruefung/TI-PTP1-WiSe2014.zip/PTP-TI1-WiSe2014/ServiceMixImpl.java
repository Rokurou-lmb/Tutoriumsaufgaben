
/**
 * Eine Klasse mit mehreren Dienstleister-Methoden.
 * Die Ruempfe sind sinnvoll zu fuellen!
 * 
 * @author (Dein Name, Deine Matrikelnummer)
 */
class ServiceMixImpl implements ServiceMix
{
    public ServiceMixImpl()
    {
        // Diesen Konstruktor unbedingt stehen lassen!
    }
    
    public String caesarVerschluesseln(String wort)
    {
        // Todo: implementieren!
        return null;
    }
    
    public String worteVerbinden(String[] worte)
    {
        // Todo: implementieren!
        return null;
    }
    
    public String ohneVokale(String wort)
    {
        // Todo: implementieren!
        return null;
    }
        
    /**
    * Gibt an, ob das gegebene Zeichen ein Vokal ist.
    */
    private boolean istVokal(char c)
    {
        c = Character.toLowerCase(c);
        return c=='a'||c=='e'||c=='i'||c=='o'||c=='u';
    }
    
    public int[] negativeZahlen(int[] zahlen)
    {
        // Todo: implementieren!
        return null;
    }

    /**
    * Gibt an, ob die Zeichenkette eine Ziffer enthaelt. Auswertungen:
    * 
    * enthaeltZiffer("ab2i") -> enthaeltZiffer("b2i") -> enthaeltZiffer("2i") -> true
    * enthaeltZiffer("xyz") -> enthaeltZiffer("yz") -> enthaeltZiffer("z") -> enthaeltZiffer("") -> false
    */
    public boolean enthaeltZiffer(String s)
    {
        // ToDo: umstrukturieren, so dass die Methode nur ein Return-Statement hat
        if (s.length() == 0)
        {
            return false;
        }
        return istZiffer(s.charAt(0)) || enthaeltZiffer (s.substring(1));
                
    }
 
    /**
    * Gibt an, ob das gegebene Zeichen eine Ziffer ist.
     */
    private boolean istZiffer(char c)
    {
        return c >= '1' && c <= '9';
    }
}
