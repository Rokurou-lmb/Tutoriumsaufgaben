/**
 * Ein Interface für Klassen, die Girokonten implementieren. 
 * Ein Girokonto kann ueberzogen werden. 
 * Implementierende Klassen muessen mindestens einen parameterlosen Konstruktor
 * anbieten, der ein neues Konto mit einem Saldo von 0 initialisiert.
 * 
 * @author Petra Becker-Pechau, Axel Schmolitzky
 * @version WiSe 2014/2015
 */
interface Girokonto
{
    /**
     * Zahlt einen Betrag auf dieses Konto ein.
     * Ein Aufruf mit negativem Betrag oder 0 fuehrt zu einer IllegalArgumentException.
     * @param betrag der einzuzahlende Betrag; muss > 0 sein.
     */
    void einzahlen(int betrag);
    
    /**
     * Zahlt einen Betrag von diesem Konto aus. 
     * Ein Aufruf mit negativem Betrag oder 0 fuehrt zu einer IllegalArgumentException.
     * @param betrag der auszuzahlende Betrag; muss > 0 sein.
     */
    void auszahlen(int betrag);
    
    /**
     * Liefert den aktuellen Saldo dieses Kontos.
     * @return den aktuellen Saldo dieses Kontos.
     */
    int gibSaldo();
    
    /**
     * Die Summe aller Einzahlungen. Achtung, der Aufruf des Konstruktors 
     * mit Anfangssaldo ist nicht als Einzahlung zu verstehen.
     * @return die Summe aller bisheriger Einzahlungen.
     */
    int summeEinzahlungen();
    
    /**
     * Die Summe aller Auszahlungen. Achtung, der Aufruf des Konstruktors 
     * mit Anfangssaldo ist nicht als Auszahlung zu verstehen, auch nicht, 
     * wenn der Anfangssaldo negativ ist.
     * @return die Summe aller bisheriger Auszahlungen.
     */
    int summeAuszahlungen();
    
    /**
     * Die Anzahl aller Einzahlungen. Achtung, der Aufruf des Konstruktors 
     * mit Anfangssaldo ist nicht als Einzahlung zu verstehen.
     * @return die Anzahl aller bisheriger Einzahlungen.
     */
    int anzahlEinzahlungen();
    
    /**
     * Die Anzahl aller Auszahlungen. Achtung, der Aufruf des Konstruktors 
     * mit Anfangssaldo ist nicht als Auszahlung zu verstehen, auch nicht, 
     * wenn der Anfangssaldo negativ ist.
     * return die Anzahl aller bisheriger Auszahlungen.
     */
    int anzahlAuszahlungen();
    
    /**
     * Der hoechste Saldo, den dieses Konto je hatte.
     * @return den hoechsten Saldo.
     */
    int hoechstenSaldo();
    
    /**
     * Der niedrigste Saldo, den dieses Konto je hatte.
     * @return den niedrigsten Saldo.
     */
    int niedrigstenSaldo();
    
}