 
/**
 * Dieses Interface spezifiziert eine Queue von Strings.
 * 
 * Die Queue verwaltet ihre Elemente nach dem FIFO-Prinzip, das zuerst 
 * eingefuegte Element wird auch als erstes zurueck geliefert.
 * 
 * Die Implementierung dieses Interfaces soll die Klasse StringKnoten
 * verwenden, die zur Verfuegung steht.
 * 
 * @author Petra Becker-Pechau 
 * @version WiSe 2014 / 2015
 */

interface StringQueue
{
    /**
     * Diese Operation fuegt einen String an das Ende der Queue an.
     * Ein Aufruf mit null fuehrt zu einer IllegalArgumentException.
     * 
     * @param s der an die Queue anzuhaengende String, darf nicht null sein.
     */   
    public void enqueue(String s);
    
    /**
     * Diese Operation liefert den vordersten String der Queue. Das ist der 
     * als erstes eingefuegte String, oder anders ausgedrueckt, der aelteste
     * String. Der String wird aus der Queue geloescht. Darf nicht aufgerufen
     * werden, wenn die Queue leer ist.
     * Ein Aufruf bei leerer Queue fuehrt zu einer IllegalStateException.
     * 
     * @return den vordersten String der Queue.
     */
    public String dequeue ();

    /**
     * Diese Operation liefert true, wenn die Queue keinen String enthaelt,
     * sonst false.
     * 
     * @return ob die Queue leer ist.
     */
    public boolean isEmpty();
}
