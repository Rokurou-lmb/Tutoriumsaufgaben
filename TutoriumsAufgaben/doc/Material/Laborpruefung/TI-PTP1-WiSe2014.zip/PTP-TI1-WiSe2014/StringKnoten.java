
/**
 * Ein Knoten für eine einfach verkettete Struktur. Der Inhalt
 * eines Knotens ist ein String, jeder Knoten kann auf einen
 * weiteren Knoten verweisen.
 * 
 * @author Petra Becker-Pechau, Axel Schmolitzky 
 * @version WiSe 2014 / 2015
 */
class StringKnoten
{
    private String _inhalt;
    private StringKnoten _nachfolger;
    
    /**
     * Initialisiert einen neuen Knoten mit seinem Inhalt, der Nachfolger
     * ist null.
     * @param inhalt der Inhalt des neuen Knotens
     */
    public StringKnoten(String inhalt)
    {
        _inhalt = inhalt;
        _nachfolger = null;
    }
        
    /**
     * Liefert den Inhalt dieses Knotens.
     * @return den Inhalt
     */
    public String gibInhalt()
    {
        return _inhalt;
    }
    
    /**
     * Setzt den uebergebenen StringKnoten als Nachfolger
     * dieses Knotens.
     * @param ein beliebiger StringKnoten
     */
    public void setzeNachfolger(StringKnoten knoten)
    {
        _nachfolger = knoten;
    }

    /**
     * Liefert den Nachfolger dieses Knotens.
     * @return den Nachfolger.
     */
    public StringKnoten gibNachfolger()
    {
        return _nachfolger;
    }
}