import java.util.Map;

/**
 * Ein weiteres Interface mit isolierten Service-Operationen.
 * 
 * @author Axel Schmolitzky
 * @version SoSe 2016
 */
interface ServiceMix3
{
    /**
     * Diese Methode bekommt den Namen einer Textdatei und liefert für
     * den in der Datei enthaltenen Text das darin am häufigsten auftretende
     * Wort mit seiner Häufigkeit. Wenn mehrere Wörter am häufigsten auftreten,
     * werden entsprechend mehr Wörter geliefert.
     * 
     * @param dateiname der Name einer Textdatei; darf nicht null sein.
     * @throws IllegalArgumentException
     * @return eine Abbildung von einem Wort auf seine Häufigkeit. 
     */
    Map<String,Integer> findeHaeufigstesWort(String dateiname);
    
}
