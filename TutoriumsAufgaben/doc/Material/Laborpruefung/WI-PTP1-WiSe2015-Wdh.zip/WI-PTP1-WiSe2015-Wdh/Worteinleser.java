import java.io.*;
import java.util.List;

/**
 * Ein Worteinleser dient zum Einlesen von Wörtern
 * aus einer Textdatei in eine gegebene Liste. Alle eingelesenen
 * Wörter werden mit Kleinbuchstaben dargestellt.
 * 
 * @author Fredrik Winkler, Petra Becker-Pechau, Axel Schmolitzky
 * @version 2010-12
 */
class Worteinleser
{
    /**
     * Liest eine Liste von Wörtern aus einer Textdatei ein.
     * @param dateiName der Dateiname der einzulesenden Textdatei
     * @param wortliste die Liste, in die die Wörter eingefügt werden
     */
    public void einlesenAusDatei(String dateiName, List<String> wortliste)
    {
        BufferedReader reader = null;
        try
        {
            reader = new BufferedReader(new FileReader(dateiName));
        }
        catch (FileNotFoundException e)
        {
            System.out.println("Fehler beim Oeffnen von " + dateiName);
        }
        try
        {
            String zeile;
            while ((zeile = reader.readLine()) != null)
            {
                if (zeile.length() > 0)
                {
                    verarbeiteZeile(zeile,wortliste);
                }
            }
            
        }
        catch (IOException e)
        {
            System.out.println("Fehler beim Lesen aus " + dateiName);
        }
        finally
        {
            try
            {
                reader.close();
            }
            catch (IOException e)
            {
                System.out.println("Fehler beim Schliessen von " + dateiName);
            }
        }
    }

    private static void verarbeiteZeile(String zeile, List<String> wortliste)
    {
        String[] woerter = zeile.toLowerCase().split("\\p{Space}");
        for (String wort : woerter)
        {
            if (wort.length() > 0)
            {
                wort = wort.replaceAll("[.,:;!?\"()]","");
                wortliste.add(wort);
            }
        }
    }
}
