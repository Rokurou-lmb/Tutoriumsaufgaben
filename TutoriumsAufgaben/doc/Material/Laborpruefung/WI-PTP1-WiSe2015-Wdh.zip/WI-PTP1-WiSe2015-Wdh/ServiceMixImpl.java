
/**
 * Eine Klasse mit mehreren Dienstleister-Methoden.
 * Die Ruempfe sind sinnvoll zu fuellen!
 * 
 * @author (Dein Name, Deine Matrikelnummer)
 */
class ServiceMixImpl implements ServiceMix
{
    public ServiceMixImpl()
    {
        // Diesen Konstruktor unbedingt stehen lassen!
    }

    public boolean enthaeltDoppelzeichen(String s)
    {
        return false;
    }
    
    public boolean enthaeltDoppelzeichenRekursiv(String s)
    {
        return false;
    }
    
    public String caesarVerschluesseln(String wort, int verschiebung)
    {
        return null;
    }

    public String zeitformatUmwandeln(String zeitIm24hFormat)
    {
        return null;
    }
    

    public int[] addiere(int[] zahlen1, int[] zahlen2)
    {
        return null;
    }

}
