
/**
 * Eine Aufzaehlungsklasse der Ticketarten.
 * 
 * @author  Axel Schmolitzky
 * @version SoSe 2016
 */
enum Ticketart
{
    EINZEL, TAG, WOCHE;
}
