
/**
 * Ein Knoten für eine einfach verkettete Liste.
 * 
 * @author Axel Schmolitzky 
 * @version SoSe 2014
 */
class StringKnoten
{
    private String _inhalt;
    private StringKnoten _nachfolger;
    
    public StringKnoten(String inhalt, StringKnoten knoten)
    {
        _inhalt = inhalt;
        _nachfolger = knoten;
    }
    
    public String gibInhalt()
    {
        return _inhalt;
    }
    
    public StringKnoten gibNachfolger()
    {
        return _nachfolger;
    }
}
