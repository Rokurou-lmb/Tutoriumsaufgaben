
/**
 * Eine Klasse mit mehreren Dienstleister-Methoden.
 * Die Rümpfe sind sinnvoll zu füllen!
 * 
 * @author (Dein Name, Deine Matrikelnummer)
 */
class ServiceMixImpl implements ServiceMix
{
    public ServiceMixImpl()
    {
        // Diesen Konstruktor unbedingt stehen lassen!
    }
    
    /**
     * Diese Methode liefert true, wenn der übergebene String ein Palindrom ist,
     * false sonst.
     * @param s ein beliebiger String, darf nicht null sein
     * @return ob s ein Palindrom ist
     */
    public boolean istPalindrom(String s)
    {
        // ToDo: implementieren
        return false;
    }
    
    /**
     * Diese Methode liefert die Summe der Quadrate der Zahlen, die als Parameter
     * in einem Array übergeben werden.
     * @param zahlen ein Array von int-Werten, darf nicht null sein
     * @return Summe der Quadrate der übergebenen Zahlen
     */
    public int quadratsumme(int[] zahlen)
    {
        // ToDo: implementieren
        return 42;
    }
    
   /**
    * Gibt an, ob die Zeichenkette einen Vokal enthaelt. Auswertungen:
    * 
    * enthaeltVokal("brei") -> enthaeltVokal("rei") -> enthaeltVokal("ei") -> true
    * enthaeltVokal("xyz") -> enthaeltVokal("yz") -> enthaeltVokal("z") -> enthaeltVokal("") -> false
    */
    public boolean enthaeltVokal(String s)
    {
        // ToDo: umstrukturieren, so dass die Methode nur ein Return-Statement hat
        if (s.length() == 0)
        {
            return false;
        }
        return istVokal(s.charAt(0)) || enthaeltVokal (s.substring(1));
    }
 
    /**
     * Gibt an, ob das gegebene Zeichen ein Vokal ist.
     */
    private boolean istVokal(char c)
    {
        c = Character.toLowerCase(c);
        return c=='a'||c=='e'||c=='i'||c=='o'||c=='u';
    }
    
    
}
