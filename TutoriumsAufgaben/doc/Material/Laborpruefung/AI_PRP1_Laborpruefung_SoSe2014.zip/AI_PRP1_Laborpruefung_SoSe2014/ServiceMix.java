
/**
 * Ein Interface mit mehreren Dienstleister-Operationen.
 * 
 * @author Axel Schmolitzky 
 * @version SoSe 2014
 */
interface ServiceMix
{
    
    /**
     * Diese Methode liefert true, wenn der übergebene String ein Palindrom ist,
     * false sonst. Auch Otto ist ein Palindrom.
     * @param s ein beliebiger String, darf nicht null sein
     * @return ob s ein Palindrom ist
     */
    public boolean istPalindrom(String s);
    
    /**
     * Diese Methode liefert die Summe der Quadrate der Zahlen, die als Parameter
     * in einem Array übergeben werden.
     * @param zahlen ein Array von int-Werten, darf nicht null sein
     * @return Summe der Quadrate der übergebenen Zahlen
     */
    public int quadratsumme(int[] zahlen);
    
   /**
    * Gibt an, ob die Zeichenkette einen Vokal enthaelt.
    */
    public boolean enthaeltVokal(String s);
    
}

