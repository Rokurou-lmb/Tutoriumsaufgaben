 
/**
 * Dieses Interface spezifiziert Stacks von Strings.
 * Die Elemente auf diesem Stack sollen also nach dem LIFO-Prinzip 
 * verwaltet werden.
 * Die Implementierung dieses Interfaces soll die Klasse StringKnoten
 * verwenden, die zur Verfügung steht.
 * 
 * @author Axel Schmolitzky 
 * @version SoSe 2014
 */

interface StringStack
{
    /**
     * Diese Operation legt einen String auf dem Stack ab.
     * @param s ein beliebiger String, der nicht null sein darf.
     */
    public void push(String s);

    /**
     * Diese Operation liefert true, wenn der Stack keinen String enthält,
     * false sonst.
     */
    public boolean isEmpty();
    
    /**
     * Diese Operation nimmt den obersten String vom Stack herunter
     * und liefert ihn als Ergebnis.
     * Diese Operation darf nur aufgerufen werden, wenn isEmpty() false liefert,
     * ansonsten wird eine IllegalStateException geworfen.
     */
    public String pop();
    
    /**
     * Diese Operation liefert den obersten String als Ergebnis, ohne
     * ihn vom Stack zu entfernen.
     * Diese Operation darf nur aufgerufen werden, wenn isEmpty() false liefert,
     * ansonsten wird eine IllegalStateException geworfen.
     */
    public String top();
}
