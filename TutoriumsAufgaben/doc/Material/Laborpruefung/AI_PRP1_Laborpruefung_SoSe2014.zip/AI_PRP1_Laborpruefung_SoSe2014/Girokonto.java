
/**
 * Ein Interface für Klassen, die Girokonten mit einem Dispo-Limit
 * implementieren. Solche Girokonten können überzogen werden,
 * aber nur bis zu einer bestimmten Grenze (dem Dispo).
 * Implementierende Klassen muessen mindestens einen parameterlosen Konstruktor
 * anbieten, der ein neues Konto mit einem Saldo und Dispo von Null initialisiert.
 * 
 * @author Axel Schmolitzky 
 * @version SoSe 2014
 */
interface Girokonto
{
    /**
     * Zahlt einen Betrag auf dieses Konto ein.
     * @param betrag der einzuzahlende Betrag; muss > 0 sein.
     */
    void einzahlen(int betrag);
    
    /**
     * Zahlt einen Betrag von diesem Konto aus. Das Konto darf dabei
     * hoechstens bis zum Dispo dieses Kontos ueberzogen werden.
     * Ein Aufruf von auszahlen, der ueber dem Dispo liegen wuerde,
     * fuehrt zu einer IllegalStateException.
     * @param betrag der auszuzahlende Betrag; muss > 0 sein.
     */
    void auszahlen(int betrag);
    
    /**
     * Liefert den aktuellen Saldo dieses Kontos.
     * @return den aktuellen Saldo dieses Kontos.
     */
    int gibSaldo();
    
    /**
     * Liefert den aktuellen Dispo dieses Kontos.
     * @return den aktuellen Dispo dieses Kontos.
     */
    int gibDispo();
    
    /**
     * Setzt den Dispo dieses Kontos auf einen neuen Wert.
     * Der neue Wert kann problemlos groesser oder gleich dem alten Wert sein.
     * Wenn er kleiner ist, ist die Aenderung nur zulaessig, wenn der aktuelle
     * Saldo innerhalb des neuen Dispos liegt; ansonsten wird eine
     * IllegalStateException geworfen.
     * @param neuerDispo der neue Dispo dieses Kontos; muss >= 0 sein, sonst
     * wird eine IllegalArgumentException geworfen.
     */
    void setzeDispo(int neuerDispo);
    
}

